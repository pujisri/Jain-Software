<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>

    <style>
        .tb {
            background-color: wheat;
            /* color: white */
        }
        
        th {
            color: black;
            font-weight: 500;
        }
        
        .btn {
            background: aquamarine;
            color: #fff;
        }
    </style>
</head>

<body>
    <br>
    <h1 align="center">{{number}}</h1><br>

    <br>
    <div class="container">
        <a href="/logout" class="btn">Logout</a><br><br>
        <h3 align="center">PROPERTIES</h3><br>
        <div style="overflow-x:auto">
            <table class="table table-striped">
                <tr class="tb">
                    <th scope="col">Property ID</th>
                    <th scope="col">Owner Name</th>
                    <th scope="col">Mobile Num</th>
                    <th scope="col">Address</th>
                    <th scope="col">City</th>
                    <th scope="col">Zip Code</th>
                    <th scope="col">kind</th>
                    <th scope="col">Area</th>
                    <th scope="col">Valuation</th>
                    <th scope="col">Status</th>

                </tr>
                {% for property in properties %}
                <tr>
                    <td>{{property[0]}}</td>
                    <td>{{property[1]}}</td>
                    <td>{{property[2]}}</td>
                    <td>{{property[3]}}</td>
                    <td>{{property[4]}}</td>
                    <td>{{property[5]}}</td>
                    <td>{{property[6]}}</td>
                    <td>{{property[7]}}</td>
                    <td>{{property[8]}}</td>
                    <td>{{property[9]}}</td>


                </tr>
                {% endfor %}
            </table>
        </div>
    </div>



</body>


</html>
